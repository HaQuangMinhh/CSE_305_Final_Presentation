public class InventoryReport implements Report {

    @Override
    public void generate() {
        System.out.println("Inventory report generated");
    }

}
