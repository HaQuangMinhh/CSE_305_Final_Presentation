import java.util.ArrayList;
import java.util.List;

public class ConcreteBicycleBuilder implements BicycleBuilder {

    private String frameSize ; 
    private String wheelType ;
    private String grearSystem ; 
    private List<String> accessories = new ArrayList<>() ;

    @Override
    public void addAccessory(List<String> accessories) {
        this.accessories.addAll(accessories);
    }

    @Override
    public void addFrameSize(String frameSize) {
        this.frameSize = frameSize ; 
    }

    @Override
    public void addGearSystem(String gearSystem) {
        this.grearSystem = gearSystem ; 
    }

    @Override
    public void addWheelType(String wheelType) {
        this.wheelType = wheelType ; 
    }

    @Override
    public Bicycle build() {
        return new Bicycle(frameSize, wheelType, grearSystem, accessories);
    }




}
