import java.util.List;

public interface BicycleBuilder {

    void addFrameSize ( String frameSize ) ;
    void addWheelType ( String wheelType );
    void addGearSystem ( String gearSystem );
    void addAccessory ( List<String> accessories );

    Bicycle build(); 
}
