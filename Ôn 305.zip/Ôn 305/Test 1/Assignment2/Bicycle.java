import java.util.List;

public class Bicycle {

    private String frameSize ; 
    private String wheelType ;
    private String grearSystem ; 
    private List<String> accessories ;
    
    public Bicycle(String frameSize, String wheelType, String grearSystem, List<String> accessories) {
        this.frameSize = frameSize;
        this.wheelType = wheelType;
        this.grearSystem = grearSystem;
        this.accessories = accessories;
    }

    @Override
    public String toString() {
        return "Bicycle [frameSize=" + frameSize + ", wheelType=" + wheelType + ", grearSystem=" + grearSystem
                + ", accessories=" + accessories + "]";
    }  
}
