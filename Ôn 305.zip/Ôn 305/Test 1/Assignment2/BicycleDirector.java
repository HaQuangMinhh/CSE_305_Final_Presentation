import java.util.Arrays;

public class BicycleDirector {

    private BicycleBuilder builder ;

    public BicycleDirector(BicycleBuilder builder) {
        this.builder = builder;
    } 

    public Bicycle buildBicycle() {

        builder.addFrameSize("medium");
        builder.addWheelType("hehe");
        builder.addGearSystem("kkk");
        builder.addAccessory( Arrays.asList("hihi", "holder") );

        return builder.build();
    }

}
