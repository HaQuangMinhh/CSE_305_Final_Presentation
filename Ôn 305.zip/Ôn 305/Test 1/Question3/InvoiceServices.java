public class InvoiceServices {

    public void processInvoice ( Order order  ) {

        System.out.println( "Invoice generated for " + order.getCustomerName() 
        + " with total amount: " + order.getOrderTotal());
    }

}
