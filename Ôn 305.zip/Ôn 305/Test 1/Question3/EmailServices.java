public class EmailServices {

    public void processEmail ( String customerEmail ) {
        System.out.println("Order confirmation email sent to " + customerEmail);
    }

}
