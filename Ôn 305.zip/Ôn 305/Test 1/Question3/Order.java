public class Order {

    private String customerName ; 
    private String customerEmail ; 
    private String shippingAddress ; 
    private double orderTotal ;
    
    
    public Order(String customerName, String customerEmail, String shippingAddress, double orderTotal) {
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.shippingAddress = shippingAddress;
        this.orderTotal = orderTotal;
    }


    public String getCustomerName() {
        return customerName;
    }


    public String getCustomerEmail() {
        return customerEmail;
    }


    public String getShippingAddress() {
        return shippingAddress;
    }


    public double getOrderTotal() {
        return orderTotal;
    } 

    

}
