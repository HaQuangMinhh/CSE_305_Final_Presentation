public class orderProcessor {

    public void processOrder(Order order) {
        System.out.println("Order processed successfully for " + order.getCustomerName());
    }

}
