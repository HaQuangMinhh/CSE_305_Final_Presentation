public class Main {


    public static void main(String[] args) {
        
        Order order = new Order("Minhvip", "hello@gmail.com", "113 main street", 650000); 

        orderProcessor orderProcessor = new orderProcessor() ; 
        EmailServices email = new EmailServices();
        InvoiceServices invoice = new InvoiceServices(); 

        orderProcessor.processOrder(order);
        email.processEmail(order.getCustomerEmail());
        invoice.processInvoice(order);




    }


}
