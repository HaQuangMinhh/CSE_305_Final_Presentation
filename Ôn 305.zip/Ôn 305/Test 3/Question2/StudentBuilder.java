public class StudentBuilder implements UserBuilder{

    private String id ; 
    private String type ; 
    private String libraryService ; 
    private String printerService ; 
    private String classService ;
    @Override
    public User createUser() {
        return new User(id, type, libraryService, printerService, classService);
    }
    @Override
    public void setClass(String classne) {
        this.classService = classne ; 
    }
    @Override
    public void setLibrary(String library) {
        this.libraryService = library ; 
    }
    @Override
    public void setPrinter(String printer) {
       this.printerService = printer ; 
    }
    @Override
    public void setType(String type) {
        this.type = type ; 
    }

    
}
