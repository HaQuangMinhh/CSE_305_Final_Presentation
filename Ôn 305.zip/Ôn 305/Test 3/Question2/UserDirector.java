public class UserDirector {

    private UserBuilder builder ;

    public UserDirector(UserBuilder builder) {
        this.builder = builder;
    } 

    public User contructStudent() {
    
        builder.setType("type1");
        builder.setLibrary("lib1");
        builder.setPrinter("printer1");
        builder.setClass("class1");

        return builder.createUser();
    }

    public User constructLecture() {

        builder.setType("type2");
        builder.setLibrary("lib2");
        builder.setPrinter("printer2");
        builder.setClass("class2");

        return builder.createUser();
    }

    public User constructAdmin() {

        builder.setType("type3");
        builder.setLibrary("lib3");
        builder.setPrinter("printer3");
        builder.setClass("class3");

        return builder.createUser();
    }

}
