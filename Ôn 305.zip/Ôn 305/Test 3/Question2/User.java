public class User {

    private String id ; 
    private String type ; 
    private String libraryService ; 
    private String printerService ; 
    private String classService ;
    
    public User(String id, String type, String libraryService, String printerService, String classService) {
        this.id = id;
        this.type = type;
        this.libraryService = libraryService;
        this.printerService = printerService;
        this.classService = classService;
    }

    @Override
    public String toString() {
        return "User [id=" + id + ", type=" + type + ", libraryService=" + libraryService + ", printerService="
                + printerService + ", classService=" + classService + "]";
    }  

}
