public class Main {


    public static void main(String[] args) {
        
        UserBuilder student = new StudentBuilder();

        UserBuilder lecture = new LecturerBuilder();

        UserBuilder admin = new AdminBuilder();

        UserDirector director1 = new UserDirector(student); 
        UserDirector director2 = new UserDirector(lecture);
        UserDirector director3 = new UserDirector(admin);
        
        User user1 = director1.contructStudent();
        User user2 = director2.constructLecture();
        User user3 = director3.constructAdmin();

        System.out.println(user1);
        System.out.println(user2);
        System.out.println(user3);
    }


}
