public interface UserBuilder {

    void setType( String type );
    void setLibrary( String library );
    void setPrinter( String printer );
    void setClass( String classne );
    
    User createUser(); 

}
