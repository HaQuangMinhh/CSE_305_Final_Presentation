public class Main {


    public static void main(String[] args) {
        
        EmployeeManager manager = new EmployeeManager();

        Employee emp1 = new Employee("vip", "ha", "be@gmail", "CIT", 50000 , Role.MANAGER ); 

        manager.addEmployee(emp1);

        manager.promoteEmployee(emp1, Role.TESTER , 800000);

        manager.removeEmployee(emp1);


    }


}
