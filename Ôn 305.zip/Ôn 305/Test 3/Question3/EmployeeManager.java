public class EmployeeManager {

    public void addEmployee( Employee employee ) {
        System.out.println( "Adding " + employee.getRole() + ", " + employee.getFirstName() + " , to department: " + employee.getDepartment() );

        System.out.println("Sending welcome mail to " + employee.getEmail());
        System.out.println("Salary set to: " + employee.getSalary());
    }

    public void promoteEmployee ( Employee employee , Role newRole , double newSalary ) {
        System.out.println("Promoting " + employee.getFirstName() );
        
        employee.setSalary(newSalary);
        employee.setRole(newRole);

    }

    public void removeEmployee ( Employee employee ) {
        System.out.println("Removing: " + employee.getRole() + ", " + employee.getFirstName());
    }


}
