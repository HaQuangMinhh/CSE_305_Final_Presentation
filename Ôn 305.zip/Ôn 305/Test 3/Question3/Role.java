public enum Role {

    MANAGER , DEVELOPER , TESTER
}
